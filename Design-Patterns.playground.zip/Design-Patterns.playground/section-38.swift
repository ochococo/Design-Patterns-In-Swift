
let planeCrew = PlaneCrew()

let order1 = Order("navigate to enemy base")
let order2 = Order("shoot at enemy plane")
let order3 = Order("stop attack!")

planeCrew.reciveOrder(order1)
planeCrew.reciveOrder(order2)
planeCrew.reciveOrder(order3)
