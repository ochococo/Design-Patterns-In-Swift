let simple = OhSoSimplePointConverter()

var tuple = simple.standarizedXYZFrom(x:1.1, y:2.2, z:3.3)

tuple.x
tuple.y
tuple.z