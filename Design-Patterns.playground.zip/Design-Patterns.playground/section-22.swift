Eternal.setObject("Disconnect me. I’d rather be nothing",forKey:"Bishop")

var bishopSaid:AnyObject! = Eternal.objectForKey("Bishop")