let cart = Cart(items: ["foo", "bar", "baz"])

for item in cart {
    println(item)
}